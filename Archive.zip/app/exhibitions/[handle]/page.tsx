// app/exhibitions/[handle]/page.tsx
import Header from "@/components/Header";
import SiteFooter from "@/components/SiteFooter";
import Container from "@/components/Container";

import ExhibitionHero from "@/components/exhibitions/ExhibitionHero";
import ExhibitionInfo from "@/components/exhibitions/ExhibitionInfo";
import InstallSlider from "@/components/exhibitions/InstallSlider";
import FeaturedWorks from "@/components/exhibitions/FeaturedWorks";
import ArtistAbout from "@/components/exhibitions/ArtistAbout";

import {
  fetchExhibitionByHandle,
  mapExhibitionDetail,
  fetchProductsForExhibition,
  fetchArtistMetaobjectByGid,
} from "@/lib/exhibitions";

import Link from "next/link";

type Props = { params: { handle: string } };

export const revalidate = 120;

export default async function ExhibitionPage({ params }: Props) {
  const raw = await fetchExhibitionByHandle(params.handle);

  if (!raw) {
    return (
      <>
        <Header />
        <main className="max-w-3xl mx-auto px-4 py-24">
          <h1 className="text-2xl font-medium mb-3">Exhibition not found</h1>
          <p className="mb-6 text-neutral-600">
            The page you’re looking for doesn’t exist or is no longer available.
          </p>
          <Link href="/exhibitions" className="underline">
            Back to Exhibitions
          </Link>
        </main>
        <SiteFooter />
      </>
    );
  }

  const ex = mapExhibitionDetail(raw.fields);
  const works = ex.exhibitionHandle
    ? await fetchProductsForExhibition(ex.exhibitionHandle)
    : [];

  const artistMeta = ex.artistRefGid
    ? await fetchArtistMetaobjectByGid(ex.artistRefGid)
    : null;

  return (
    <>
      {/* Transparent/overlay header like home */}
      <Header overlay />

      {/* HERO */}
      <ExhibitionHero image={ex.hero} title={ex.title ?? undefined} />

      {/* INFO + TEXT */}
      {(ex.start || ex.end || ex.location || ex.blurb || ex.text) && (
        <section className="py-10 md:py-14">
          <Container>
            <ExhibitionInfo
              title={ex.title ?? undefined}
              artist={ex.artist ?? undefined}
              start={ex.start ?? undefined}
              end={ex.end ?? undefined}
              location={ex.location ?? undefined}
              blurb={ex.blurb ?? undefined}
              text={ex.text ?? undefined}
            />
          </Container>
        </section>
      )}

      {/* INSTALLATION VIEWS */}
      {ex.install?.length ? (
        <section className="py-10 md:py-14">
          <Container>
            <InstallSlider images={ex.install} />
          </Container>
        </section>
      ) : null}

      {/* FEATURED WORKS */}
      {works.length ? (
        <section className="py-10 md:py-16">
          <Container>
            <FeaturedWorks
              works={works}
              defaultArtist={ex.artist ?? undefined}
            />
          </Container>
        </section>
      ) : null}

      {/* ABOUT THE ARTIST */}
      {artistMeta?.bio && (
        <section className="py-10 md:py-16">
          <Container>
            <ArtistAbout
              name={artistMeta.name ?? ex.artist ?? ""}
              bio={artistMeta.bio}
              portrait={artistMeta.portrait ?? undefined}
            />
          </Container>
        </section>
      )}

      <SiteFooter />
    </>
  );
}
