// lib/nav.ts
export const NAV_LINKS = [
  { href: "/artists", label: "Artists" },
  { href: "/exhibitions", label: "Exhibitions" },
  { href: "/collect", label: "Collect" },
  { href: "/about", label: "About" },
];
